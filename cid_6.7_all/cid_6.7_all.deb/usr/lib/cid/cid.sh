#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
#---------------------------------------------------#


Menu () {


# --- CONTROLE DE STATUS --- #

if [ -e /usr/lib/cid/control/current_domain.txt ] && [ "`cat /usr/lib/cid/control/current_domain.txt`" != "" ]; then
	modo='Remover do'
	status="fqdn: `hostname | tr [:upper:] [:lower:]`.`cat /usr/lib/cid/control/current_domain.txt`"
else
	modo='Ingressar no'
	status="Hostname: `hostname`"
fi


# --- MENU PRINCIPAL --- #


OP=`zenity --list \
	 --title="*** Closed In Directory ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png --radiolist --hide-header \
	 --text="
 $status
" \
	 --column="" --column="" \
	"1" "
$modo domínio
" \
	"2" "
Sobre o cid
" \
	"3" "
Sair
"`

if [ "`echo $OP | grep Ingressar`" != "" ]; then

	Ingressar

elif [ "`echo $OP | grep Remover`" != "" ]; then

	Remover

elif [ "`echo $OP | grep Sobre`" != "" ]; then

	Dados=`aptitude show cid`

	if [ "`echo $Dados`" = "" ]; then

		Dados=`dpkg -p cid`

		if [ "`echo $Dados`" = "" ]; then

			Dados="Pacote: cid
Versão: `dpkg -p cid | grep Version | cut -d " " -f 2`
Prioridade: opcional
Seção: System
Mantenedor: Eduardo Moraes <emoraes25@gmail.com>
Depende de: samba, smbclient, smbfs|cifs-utils, cifs-utils|smbfs, libpam-mount, libnss-winbind|winbind, libpam-winbind|winbind, winbind, libpam-krb5, krb5-config, krb5-user, nss-updatedb, libnss-db, libpam-ccreds, ntpdate
Pré-Depende de: sudo, gksu|kdesudo, zenity
Recomenda: dconf-tools|gconf-editor
Sugere: aptitude, dnsutils, kdesudo
Descrição: *** Closed In Directory ***
 
 Linux \"em diretório fechado\". Integra distribuições Linux ao serviço de diretório \"Microsoft Active Directory\". 
 
Página web: http://sourceforge.net/projects/c-i-d/"
		fi

	fi

echo "$Dados

GNU GENERAL PUBLIC LICENSE

Version 3, 29 June 2007
Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Everyone is permitted to copy and distribute verbatim copies 
of this license document, but changing it is not allowed." > /usr/lib/cid/tmp/about.txt

	zenity --text-info --title="*** Sobre o cid... ***" --width="540" --height="700" --window-icon=/usr/share/icons/cid.png --filename="/usr/lib/cid/tmp/about.txt"

	Menu

else

	exit

fi
}


#---------------------------------------------------#


Ingressar () {


# --- COLETANDO INFORMAÇÕES --- #

( 
	echo "50" ; sleep 1
	echo "100" ; sleep 1 
) | zenity --progress --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Coletando Informações...
" --percentage=0 --pulsate --auto-close


domain_lw=`zenity --entry \
	 --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
	 --text="
 Domínio:
" \
	--entry-text "exemplo.local"`

if [ "$?" = 1 ] || [ "$?" = -1 ]; then
	Menu
fi


# --- TRATAMENTO DE VARIÁVEIS --- #

domain_lw=`echo "$domain_lw" | tr [:upper:] [:lower:]`

domain_up=`echo "$domain_lw" | tr [:lower:] [:upper:]`

domain=`echo "$domain_up" | cut -d "." -f 1`

SO=`lsb_release -d | cut -d ':' -f 2 | sed -r "s/^\t//g"`

SO_Version=`lsb_release -r | cut -d ':' -f 2 | sed -r "s/^\t//g"`

if [ "$SO" = "" ]; then
	SO='Closed In Directory'
fi

if [ "$SO_Version" = "" ]; then
	SO_Version=`dpkg -p cid | grep Version | cut -d " " -f 2`
fi


# --- VERIFICANDO NOME NETBIOS DO DOMÍNIO --- #

if [ "`which nmblookup`" != "" ]; then

	workgroup=`nmblookup -A $domain_lw | grep '<GROUP>' | grep '<00>' | head -1 | tr -d [:blank:] | cut -d '<' -f 1`

	if [ "`echo $workgroup`" != "" ] && [ "`echo $workgroup`" != "`echo $domain`" ] && [ "$workgroup" != "WORKGROUP" ]; then
		domain=`echo "$workgroup" | tr [:lower:] [:upper:]`
	fi
fi


# --- RECOLHENDO AUTENTICAÇÃO --- #

dono=`zenity --entry \
	 --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
	 --text="
 Usuário (Admins. do domínio):
" \
	--entry-text "Administrador"`

if [ "$?" = 1 ] || [ "$?" = -1 ]; then
	Menu
fi

pass=`zenity --entry \
	 --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
	 --text="
 Senha de \"$dono\":
" \
	--hide-text`

if [ "$?" = 1 ] || [ "$?" = -1 ]; then
	Menu
fi


# --- BACKUP DOS ARQUIVOS DE CONFIGURAÇÃO --- #

Backup


# --- MODIFICANDO ARQUIVOS DE CONFIGURAÇÃO --- #

echo "# Modified by cid
# By Eduardo Moraes <emoraes25@gmail.com>
# -------------------------------------------------

[libdefaults]
	default_realm = $domain_up
	dns_lookup_realm = true
	dns_lookup_kdc = true
	max_retries = 1
	ticket_lifetime = 7d
	renew_lifetime = 7d
	forwardable = true
	fcc-mit-ticketflags = true

[realms]
	$domain_up = {
		kdc = $domain_lw
		admin_server = $domain_lw
		default_domain = $domain_up
	}

[domain_realm]
	.$domain_lw = $domain_up
	$domain_lw = $domain_up

[login]
	krb4_convert = true
	krb4_get_tickets = false" > /etc/krb5.conf


echo '# Modified by cid
# By Eduardo Moraes <emoraes25@gmail.com>
# -------------------------------------------------

passwd:         compat winbind [NOTFOUND=return] db
group:          compat winbind [NOTFOUND=return] db
shadow:         compat

hosts:          files mdns4_minimal [NOTFOUND=return] dns mdns4
networks:       files

protocols:      db files
services:       db files
ethers:         db files
rpc:            db files

netgroup:       nis' > /etc/nsswitch.conf


echo "# Modified by cid
# By Eduardo Moraes <emoraes25@gmail.com>
# -------------------------------------------------

[global]
	workgroup = $domain
	realm = $domain_up
	security = ADS
	template homedir = /home/%U
	template shell = /bin/bash
	winbind reconnect delay = 0
	winbind refresh tickets = Yes
	winbind enum users = Yes
	winbind enum groups = Yes
	winbind use default domain = Yes
	winbind offline logon = Yes
	winbind uid = 10000-2000000
	winbind gid = 10000-2000000" > /etc/samba/smb.conf


# --- INSERINDO NO DOMÍNIO --- #

( 
	echo "35" ; sleep 1
	/etc/init.d/winbind restart
	echo "70" ; sleep 1
	ntpdate $domain_lw
	echo "100" ; sleep 1 
) | zenity --progress --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Inserindo no domínio...
" --percentage=0 --pulsate --auto-close

net ads join osName="$SO" osVer="$SO_Version" -U $dono%$pass

if [ "$?" = 0 ]; then

	zenity --info --window-icon=/usr/share/icons/cid.png --text="
Bem-vindo ao domínio \"$domain\"
"
	echo "$domain_lw" > /usr/lib/cid/control/current_domain.txt

	if [ ! -e /usr/lib/cid/control/userLogons_history.txt ]; then
		touch /usr/lib/cid/control/userLogons_history.txt
	fi

	chmod 666 /usr/lib/cid/control/userLogons_history.txt

else

	zenity --error --window-icon=/usr/share/icons/cid.png --text="
	Falha no ingresso em \"$domain\"!


 - Verifique os dados informados e as configurações
de rede!

 - Certifique-se de que há comunicação desta estação
com o contralador de domínio!

 - Execute os seguintes comandos de teste no terminal:


	--> nslookup $domain_lw

	--> ping -c 4 $domain_lw


Se obtiver êxito nos testes, reinicie o sistema e
tente novamente realizar o ingresso no domínio.
Do contrário, confirme o seu servidor DNS e 
configure corretamente os parâmetros de rede!"

	Restore

	Menu

fi


# --- REINICIANDO O SERVIÇO --- #

( 
	echo "50" ; sleep 1
	/etc/init.d/winbind restart
	echo "100" ; sleep 1 
) | zenity --progress --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Reiniciando o serviço...
" --percentage=0 --pulsate --auto-close


# --- FINALIZANDO CONFIGURAÇÕES --- #

( 
	echo "25" ; sleep 1
	echo "# Alterando arquivos de configuração do sistema..." ; sleep 1


 # --> Configurações em "/etc/profile"

if [ "`grep -ax '# --- < Modified by cid > --- #' /etc/profile`" != "" ]; then
	cp -f /usr/lib/cid/backup/profile /etc/profile
fi

echo '

# --- < Modified by cid > --- #


sh /usr/lib/cid/exec/uid_logon.sh' >> /etc/profile

chmod +x /usr/lib/cid/exec/uid_logon.sh


 # --> Configurações em "/etc/sudoers"

if [ "`grep -ax '# --- < Modified by cid > --- #' /etc/sudoers`" != "" ]; then
	cp -f /usr/lib/cid/backup/sudoers /etc/sudoers
fi

wbinfo -g | grep -Ewi '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' > /usr/lib/cid/tmp/group.txt

if [ "`cat /usr/lib/cid/tmp/group.txt`" = "" ]; then
	getent group | grep -Ewi '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' | cut -d ":" -f 1 > /usr/lib/cid/tmp/group.txt
fi

if [ "`cat /usr/lib/cid/tmp/group.txt`" = "" ]; then

	echo "

# --- < Modified by cid > --- #

ALL ALL=(ALL) NOPASSWD: /bin/umount
ALL ALL=(ALL) NOPASSWD: /usr/lib/cid/exec/addUser_lpadmin.sh
ALL ALL=(ALL) NOPASSWD: /usr/lib/cid/fix_bug/fix_sudoers.sh" >> /etc/sudoers

	echo 'sudo /usr/lib/cid/fix_bug/fix_sudoers.sh' >> /usr/lib/cid/exec/uid_logon.sh

	chmod +x /usr/lib/cid/fix_bug/fix_sudoers.sh
else
	sed -i 's/\\/\\\\/ig' /usr/lib/cid/tmp/group.txt

	sed -i 's/ /\\ /ig' /usr/lib/cid/tmp/group.txt

	sed -i "s/^/%/ig" /usr/lib/cid/tmp/group.txt

	sed -i "s/$/ ALL=(ALL) NOPASSWD: ALL/ig" /usr/lib/cid/tmp/group.txt

	echo "

# --- < Modified by cid > --- #

ALL ALL=(ALL) NOPASSWD: /bin/umount
ALL ALL=(ALL) NOPASSWD: /usr/lib/cid/exec/addUser_lpadmin.sh" >> /etc/sudoers

	cat /usr/lib/cid/tmp/group.txt >> /etc/sudoers
fi

if [ "`grep -aEwi "^%admin" /etc/sudoers | grep -w 'NOPASSWD:'`" = "" ]; then
	old=`grep -aEwi "^%admin" /etc/sudoers`
	new=`grep -aEw "^%admin" /etc/sudoers | sed -r "s/ALL$/NOPASSWD: ALL/"`
	sed -i "s/$old/$new/" /etc/sudoers
fi

if [ "`grep -aEwi "^%sudo" /etc/sudoers | grep -w 'NOPASSWD:'`" = "" ]; then
	old=`grep -aEwi "^%sudo" /etc/sudoers`
	new=`grep -aEw "^%sudo" /etc/sudoers | sed -r "s/ALL$/NOPASSWD: ALL/"`
	sed -i "s/$old/$new/" /etc/sudoers
fi

chmod +x /usr/lib/cid/exec/addUser_lpadmin.sh

echo 'exit 0' >> /usr/lib/cid/exec/uid_logon.sh


 # --> Configurações em "/etc/pam.d/*"

if [ "`grep -aw 'pam_ldap.so' /etc/pam.d/common-auth | grep -Ev "^#"`" != "" ]; then
	apt-get remove libpam-ldap -y
fi

cd /usr/lib/cid/config_files
for PAM in `ls common-*`
do
	if [ -e /etc/pam.d/$PAM ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/$PAM`" != "" ]; then
		cp -f /usr/lib/cid/backup/$PAM /etc/pam.d/$PAM
	fi

	cp -f $PAM /usr/lib/cid/tmp/$PAM

	grep -aEwv '(pam_ldap.so|pam_krb5.so|pam_winbind.so|pam_unix.so|pam_ccreds.so|pam_deny.so|pam_permit.so|pam_mount.so|pam_gnome_keyring.so|pam_umask.so|pam_exec.so|^#|^$)' /etc/pam.d/$PAM >> /usr/lib/cid/tmp/$PAM

	cp -f /usr/lib/cid/tmp/$PAM /etc/pam.d/$PAM
done
cd -

if [ ! -e /usr/lib/cid/backup/PAM ]; then
	mkdir -p /usr/lib/cid/backup/PAM
fi

cd /etc/pam.d
for FILE in `find ./* | grep -Ewv "(mdm|gdm|kdm|lxdm|slim|sddm|lightdm|xdm|wdm|qingy|entrance)$" | grep -v "common-"`
do
	old=`grep -aEwi "^@include" $FILE | grep -Ewi "common-session$"`

	if [ "`echo $old`" != "" ]; then
		if [ ! -e /usr/lib/cid/backup/PAM/$FILE ] && [ "`grep -aw 'Modified by cid' $FILE`" = "" ]; then
			cp -f $FILE /usr/lib/cid/backup/PAM/$FILE
		fi

		sed -i "s/$old/@include common-session-noninteractive/" $FILE

		echo '# --- < Modified by cid > --- #' >> $FILE
	fi
done
cd -


 # --> Configurações em "/etc/rc.local"

if [ "`grep -ax '# --- < Modified by cid > --- #' /etc/rc.local`" != "" ]; then
	cp -f /usr/lib/cid/backup/rc.local /etc/rc.local
fi

sed -i "/^exit 0/d" /etc/rc.local

echo '

# --- < Modified by cid > --- #

if [ "`mount | grep -w /mnt/.netlogon`" != "" ]; then

	if [ -e "/mnt/.netlogon/scripts_cid/shares.xml" ] && [ -e "/etc/security/pam_mount.conf.xml" ]; then
		cp -f /mnt/.netlogon/scripts_cid/shares.xml /etc/security/pam_mount.conf.xml
	fi

	if [ -e "/mnt/.netlogon/scripts_cid/.logon_(root).sh" ]; then
		sh "/mnt/.netlogon/scripts_cid/.logon_(root).sh"
	fi
fi

exit 0' >> /etc/rc.local


 # --> Configurações em "/etc/fstab"

if [ "`grep -aw 'Modified by cid' /etc/fstab`" != "" ]; then
	cp -f /usr/lib/cid/backup/fstab /etc/fstab
fi

echo "

# --- < Modified by cid > --- < NETLOGON in $domain_lw > --- #

//$domain_lw/netlogon /mnt/.netlogon cifs users,credentials=/usr/lib/cid/control/.key_netlogon,file_mode=0775,dir_mode=0775,iocharset=utf8,mapchars,nocase,soft 0 0" >> /etc/fstab

echo "username=$dono
password=$pass
domain=$domain_lw" > /usr/lib/cid/control/.key_netlogon

chmod 600 /usr/lib/cid/control/.key_netlogon
chmod 600 /etc/fstab

if [ ! -e /mnt/.netlogon ]; then
	mkdir -p /mnt/.netlogon
fi


# --- EXPORTANDO SCRIPT DE LOGON PARA NETLOGON --- #


	echo "50" ; sleep 1
	echo "# Exportando script de logon..." ; sleep 1


mount -a

if [ "`mount | grep -w /mnt/.netlogon`" != "" ]; then

	if [ -e /mnt/.netlogon/scripts_cid ]; then

		if [ ! -e /mnt/.netlogon/scripts_cid/logon.sh ]; then
			cp -f /usr/lib/cid/scripts_cid/logon.sh /mnt/.netlogon/scripts_cid/logon.sh
		fi

		if [ ! -e "/mnt/.netlogon/scripts_cid/.logon_(root).sh" ]; then
			cp -f "/usr/lib/cid/scripts_cid/.logon_(root).sh" "/mnt/.netlogon/scripts_cid/.logon_(root).sh"
		fi

		if [ ! -e /mnt/.netlogon/scripts_cid/shares.xml ]; then
			cp -f /usr/lib/cid/scripts_cid/shares.xml /mnt/.netlogon/scripts_cid/shares.xml
		else
			cp -f /mnt/.netlogon/scripts_cid/shares.xml /etc/security/pam_mount.conf.xml
		fi
	else
		cp -rf /usr/lib/cid/scripts_cid /mnt/.netlogon/
	fi

	umount /mnt/.netlogon
fi


# --- ALTERANDO CONFIGURAÇÕES DO GERENCIADOR DE LOGON (GDM/LIGHTDM) --- #


	echo "75" ; sleep 1
	echo "# Alterando configurações do gerenciador de logon..." ; sleep 1


if [ -e /etc/lightdm/lightdm.conf ]; then

	if [ "`grep -aw 'greeter-show-manual-login=true' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-show-manual-login=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-show-manual-login=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-show-manual-login=true/ig" /etc/lightdm/lightdm.conf
		else
			echo 'greeter-show-manual-login=true' >> /etc/lightdm/lightdm.conf
		fi
	fi

	if [ "`grep -aw 'greeter-hide-users=true' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-hide-users=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-hide-users=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-hide-users=true/ig" /etc/lightdm/lightdm.conf
		else
			echo 'greeter-hide-users=true' >> /etc/lightdm/lightdm.conf
		fi
	fi

	if [ "`grep -aw 'allow-guest=false' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'allow-guest=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'allow-guest=' /etc/lightdm/lightdm.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/allow-guest=false/ig" /etc/lightdm/lightdm.conf
		else
			echo 'allow-guest=false' >> /etc/lightdm/lightdm.conf
		fi
	fi

elif [ -e /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf ]; then

	if [ "`grep -aw 'greeter-show-manual-login=true' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-show-manual-login=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-show-manual-login=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-show-manual-login=true/ig" /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		else
			echo 'greeter-show-manual-login=true' >> /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		fi
	fi

	if [ "`grep -aw 'greeter-hide-users=true' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-hide-users=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-hide-users=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-hide-users=true/ig" /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		else
			echo 'greeter-hide-users=true' >> /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		fi
	fi

	if [ "`grep -aw 'allow-guest=false' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'allow-guest=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'allow-guest=' /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/allow-guest=false/ig" /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		else
			echo 'allow-guest=false' >> /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
		fi
	fi

elif [ -e /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf ]; then

	if [ "`grep -aw 'greeter-show-manual-login=true' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-show-manual-login=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-show-manual-login=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-show-manual-login=true/ig" /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		else
			echo 'greeter-show-manual-login=true' >> /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		fi
	fi

	if [ "`grep -aw 'greeter-hide-users=true' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'greeter-hide-users=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'greeter-hide-users=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/greeter-hide-users=true/ig" /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		else
			echo 'greeter-hide-users=true' >> /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		fi
	fi

	if [ "`grep -aw 'allow-guest=false' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" = "" ]; then
		if [ "`grep -a 'allow-guest=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`" != "" ]; then
			parametro="`grep -a 'allow-guest=' /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf | grep -Ev "^#"`"
			sed -i "s/$parametro/allow-guest=false/ig" /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		else
			echo 'allow-guest=false' >> /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
		fi
	fi

elif [ -e /etc/init.d/gdm ] && [ ! -e /etc/init.d/lightdm ]; then
	sudo -u gdm gconftool-2 --set --type boolean /apps/gdm/simple-greeter/disable_user_list true
fi


	echo "100" ; sleep 1
) | zenity --progress --title="*** Ingressando no domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Finalizando configurações...
" --percentage=0 --auto-close


# --- FINALIZANDO --- #

Finalizar
}


#---------------------------------------------------#


Remover () {


# --- TRATAMENTO DE VARIÁVEIS --- #

domain_lw=`grep -aw 'realm' /etc/samba/smb.conf | cut -d "=" -f 2 | sed 's/ //ig' | tr [:upper:] [:lower:]`


# --- RECOLHENDO AUTENTICAÇÃO --- #

( 
	echo "50" ; sleep 1
	echo "100" ; sleep 1 
) | zenity --progress --title="*** Removendo do domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Coletando Informações...
" --percentage=0 --pulsate --auto-close


dono=`zenity --entry \
	 --title="*** Removendo do domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
	 --text="
 Usuário (Admins. do domínio):
" \
	--entry-text "Administrador"`

if [ "$?" = 1 ] || [ "$?" = -1 ]; then
	Menu
fi

pass=`zenity --entry \
	 --title="*** Removendo do domínio... ***" --width="450" --height="600" --window-icon=/usr/share/icons/cid.png \
	 --text="
 Senha de \"$dono\":
" \
	--hide-text`

if [ "$?" = 1 ] || [ "$?" = -1 ]; then
	Menu
fi


# --- REMOVENDO DO DOMÍNIO --- #

( 
	echo "50" ; sleep 1
	ntpdate $domain_lw
	echo "100" ; sleep 1 
) | zenity --progress --title="*** Removendo do domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Excluindo do domínio...
" --percentage=0 --pulsate --auto-close

net ads leave -U $dono%$pass

if [ "$?" = 0 ]; then

	zenity --info --text="
Conta removida com êxito!
"
	rm -f /usr/lib/cid/control/current_domain.txt

	rm -f /usr/lib/cid/control/.key_netlogon
else

	zenity --error --window-icon=/usr/share/icons/cid.png --text="
	Falha na remoção da conta de computador!


 - Verifique os dados informados e as configurações
de rede!

 - Certifique-se de que há comunicação desta estação
com o contralador de domínio!

 - Execute os seguintes comandos de teste no terminal:


	--> nslookup $domain_lw

	--> ping -c 4 $domain_lw


Se obtiver êxito nos testes, reinicie o sistema e
tente novamente realizar a remoção do domínio!
"

	Menu
fi


# --- FINALIZANDO CONFIGURAÇÕES --- #

( 
	echo "25" ; sleep 1
	echo "# Restaurando backup dos arquivos de configuração..." ; sleep 1


 # --> Executando função Restore

Restore


 # --> Restauração em "/etc/pam.d/*"

if [ -e /usr/lib/cid/backup/PAM ]; then
	cd /usr/lib/cid/backup/PAM
	for FILE in `ls *`
	do
		if [ -e /etc/pam.d/$FILE ]; then
			cp -f $FILE /etc/pam.d/$FILE
		fi
	done
	cd -
	rm -rf /usr/lib/cid/backup/PAM
fi


 # --> Restauração em "/usr/lib/cid/exec/uid_logon.sh"

if [ "`grep -ax 'exit 0' /usr/lib/cid/exec/uid_logon.sh`" != "" ]; then
	sed -i "/^exit 0/d" /usr/lib/cid/exec/uid_logon.sh
fi


# --- LIMPANDO USUÁRIOS DO DOMÍNIO DOS GRUPOS LOCAIS DO SISTEMA --- #


	echo "50" ; sleep 1
	echo "# Limpando usuários do domínio dos grupos locais do sistema..." ; sleep 1

if [ -e /usr/lib/cid/control/userLogons_history.txt ] && [ "`cat /usr/lib/cid/control/userLogons_history.txt`" != "" ]; then

	cp -f /usr/lib/cid/control/userLogons_history.txt /usr/lib/cid/tmp/userLogons_history.txt

	sed -i 's/_/###/g' /usr/lib/cid/tmp/userLogons_history.txt
	sed -i 's/\\/_/g' /usr/lib/cid/tmp/userLogons_history.txt

	if [ "`grep -a '_' /usr/lib/cid/tmp/userLogons_history.txt`" != "" ]; then

		grep -a '_' /usr/lib/cid/tmp/userLogons_history.txt > /usr/lib/cid/tmp/userLogons_history_subdomains.txt
		grep -av '_' /usr/lib/cid/tmp/userLogons_history.txt > /usr/lib/cid/tmp/userLogons_history_domain.txt

		sed -i 's/_/\\/g' /usr/lib/cid/tmp/userLogons_history_subdomains.txt
		sed -i 's/###/_/g' /usr/lib/cid/tmp/userLogons_history_subdomains.txt
		sed -i 's/###/_/g' /usr/lib/cid/tmp/userLogons_history_domain.txt

		cp -f /etc/group /usr/lib/cid/snapshots/group
		sed -i 's/\\/_/g' /etc/group

		for u in `cat /usr/lib/cid/tmp/userLogons_history_subdomains.txt`
		do
			DOMAIN=`echo $u | cut -d '\' -f1`
			user=`echo $u | cut -d '\' -f2`
			DOMAIN_user="`echo $DOMAIN`_`echo $user`"
			sed -i "s/,$DOMAIN_user//g" /etc/group
		done

		for u in `cat /usr/lib/cid/tmp/userLogons_history_domain.txt`
		do
			sed -i "s/,$u//ig" /etc/group
		done

		rm -f /usr/lib/cid/tmp/userLogons_history_subdomains.txt
		rm -f /usr/lib/cid/tmp/userLogons_history_domain.txt
	else
		for u in `cat /usr/lib/cid/tmp/userLogons_history.txt`
		do
			sed -i "s/,$u//ig" /etc/group
		done
	fi

	rm -f /usr/lib/cid/tmp/userLogons_history.txt
	rm -f /usr/lib/cid/control/userLogons_history.txt
fi


# --- RESTAURANDO CONFIGURAÇÕES DO GERENCIADOR DE LOGON (GDM) --- #
 

	echo "75" ; sleep 1
	echo "# Restaurando configurações do gerenciador de logon..." ; sleep 1


if [ -e /etc/init.d/gdm ] && [ ! -e /etc/init.d/lightdm ]; then
	sudo -u gdm gconftool-2 --set --type boolean /apps/gdm/simple-greeter/disable_user_list false
fi


	echo "100" ; sleep 1
) | zenity --progress --title="*** Removendo do domínio... ***" --width="450" --height="550" --window-icon=/usr/share/icons/cid.png \
 --text="
Finalizando configurações...
" --percentage=0 --auto-close


# --- FINALIZANDO --- #

Finalizar
}


#---------------------------------------------------#


Backup () {

if [ ! -e /usr/lib/cid/backup/group ]; then
	cp -f /etc/group /usr/lib/cid/backup/group
fi

if [ ! -e /usr/lib/cid/backup/krb5.conf ] && [ "`grep -aw 'Modified by cid' /etc/krb5.conf`" = "" ]; then
	cp -f /etc/krb5.conf /usr/lib/cid/backup/krb5.conf
fi

if [ ! -e /usr/lib/cid/backup/nsswitch.conf ] && [ "`grep -aw 'Modified by cid' /etc/nsswitch.conf`" = "" ]; then
	cp -f /etc/nsswitch.conf /usr/lib/cid/backup/nsswitch.conf
fi

if [ ! -e /usr/lib/cid/backup/smb.conf ] && [ "`grep -aw 'Modified by cid' /etc/samba/smb.conf`" = "" ]; then
	cp -f /etc/samba/smb.conf /usr/lib/cid/backup/smb.conf
fi

if [ ! -e /usr/lib/cid/backup/common-account ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/common-account`" = "" ]; then
	cp -f /etc/pam.d/common-account /usr/lib/cid/backup/common-account
fi

if [ ! -e /usr/lib/cid/backup/common-auth ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/common-auth`" = "" ]; then
	cp -f /etc/pam.d/common-auth /usr/lib/cid/backup/common-auth
fi

if [ ! -e /usr/lib/cid/backup/common-password ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/common-password`" = "" ]; then
	cp -f /etc/pam.d/common-password /usr/lib/cid/backup/common-password
fi

if [ ! -e /usr/lib/cid/backup/common-session ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/common-session`" = "" ]; then
	cp -f /etc/pam.d/common-session /usr/lib/cid/backup/common-session
fi

if [ ! -e /usr/lib/cid/backup/common-session-noninteractive ] && [ "`grep -aw 'Modified by cid' /etc/pam.d/common-session-noninteractive`" = "" ]; then
	cp -f /etc/pam.d/common-session-noninteractive /usr/lib/cid/backup/common-session-noninteractive
fi

if [ ! -e /usr/lib/cid/backup/pam_mount.conf.xml ] && [ "`grep -aw 'pam_mount.conf(5)' /etc/security/pam_mount.conf.xml`" != "" ]; then
	cp -f /etc/security/pam_mount.conf.xml /usr/lib/cid/backup/pam_mount.conf.xml
fi

if [ ! -e /usr/lib/cid/backup/profile ] && [ "`grep -aw 'Modified by cid' /etc/profile`" = "" ]; then
	cp -f /etc/profile /usr/lib/cid/backup/profile
fi

if [ ! -e /usr/lib/cid/backup/sudoers ] && [ "`grep -aw 'Modified by cid' /etc/sudoers`" = "" ]; then
	cp -f /etc/sudoers /usr/lib/cid/backup/sudoers
fi

if [ ! -e /usr/lib/cid/backup/rc.local ] && [ "`grep -aw 'Modified by cid' /etc/rc.local`" = "" ]; then
	cp -f /etc/rc.local /usr/lib/cid/backup/rc.local
fi

if [ ! -e /usr/lib/cid/backup/fstab ] && [ "`grep -aw 'Modified by cid' /etc/fstab`" = "" ]; then
	cp -f /etc/fstab /usr/lib/cid/backup/fstab
fi

if [ -e /etc/lightdm/lightdm.conf ] && [ ! -e /usr/lib/cid/backup/lightdm.conf ]; then

	cp -f /etc/lightdm/lightdm.conf /usr/lib/cid/backup/lightdm.conf

elif [ -e /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf ] && [ ! -e /usr/lib/cid/backup/50-unity-greeter.conf ]; then

	cp -f /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf /usr/lib/cid/backup/50-unity-greeter.conf

elif [ -e /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf ] && [ ! -e /usr/lib/cid/backup/50-ubuntu.conf ]; then

	cp -f /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf /usr/lib/cid/backup/50-ubuntu.conf

fi
}


#---------------------------------------------------#


Restore () {

if [ ! -e /usr/lib/cid/snapshots ]; then
	mkdir -p /usr/lib/cid/snapshots
fi

if [ -e /usr/lib/cid/backup/krb5.conf ]; then
	cp -f /etc/krb5.conf /usr/lib/cid/snapshots/krb5.conf
	cp -f /usr/lib/cid/backup/krb5.conf /etc/krb5.conf
fi

if [ -e /usr/lib/cid/backup/nsswitch.conf ]; then
	cp -f /etc/nsswitch.conf /usr/lib/cid/snapshots/nsswitch.conf
	cp -f /usr/lib/cid/backup/nsswitch.conf /etc/nsswitch.conf
fi

if [ -e /usr/lib/cid/backup/smb.conf ]; then
	cp -f /etc/samba/smb.conf /usr/lib/cid/snapshots/smb.conf
	cp -f /usr/lib/cid/backup/smb.conf /etc/samba/smb.conf
fi
 
if [ -e /usr/lib/cid/backup/common-account ]; then
	cp -f /etc/pam.d/common-account /usr/lib/cid/snapshots/common-account
	cp -f /usr/lib/cid/backup/common-account /etc/pam.d/common-account
fi

if [ -e /usr/lib/cid/backup/common-auth ]; then
	cp -f /etc/pam.d/common-auth /usr/lib/cid/snapshots/common-auth
	cp -f /usr/lib/cid/backup/common-auth /etc/pam.d/common-auth
fi

if [ -e /usr/lib/cid/backup/common-password ]; then
	cp -f /etc/pam.d/common-password /usr/lib/cid/snapshots/common-password
	cp -f /usr/lib/cid/backup/common-password /etc/pam.d/common-password
fi

if [ -e /usr/lib/cid/backup/common-session ]; then
	cp -f /etc/pam.d/common-session /usr/lib/cid/snapshots/common-session
	cp -f /usr/lib/cid/backup/common-session /etc/pam.d/common-session
fi

if [ -e /usr/lib/cid/backup/common-session-noninteractive ]; then
	cp -f /etc/pam.d/common-session-noninteractive /usr/lib/cid/snapshots/common-session-noninteractive
	cp -f /usr/lib/cid/backup/common-session-noninteractive /etc/pam.d/common-session-noninteractive
fi

if [ -e /usr/lib/cid/backup/pam_mount.conf.xml ]; then
	cp -f /etc/security/pam_mount.conf.xml /usr/lib/cid/snapshots/pam_mount.conf.xml
	cp -f /usr/lib/cid/backup/pam_mount.conf.xml /etc/security/pam_mount.conf.xml
fi

if [ -e /usr/lib/cid/backup/profile ]; then
	cp -f /etc/profile /usr/lib/cid/snapshots/profile
	cp -f /usr/lib/cid/backup/profile /etc/profile
fi

if [ -e /usr/lib/cid/backup/sudoers ]; then
	cp -f /etc/sudoers /usr/lib/cid/snapshots/sudoers
	cp -f /usr/lib/cid/backup/sudoers /etc/sudoers
fi

if [ -e /usr/lib/cid/backup/rc.local ]; then
	cp -f /etc/rc.local /usr/lib/cid/snapshots/rc.local
	cp -f /usr/lib/cid/backup/rc.local /etc/rc.local
fi

if [ -e /usr/lib/cid/backup/fstab ]; then
	cp -f /etc/fstab /usr/lib/cid/snapshots/fstab
	cp -f /usr/lib/cid/backup/fstab /etc/fstab
fi

if [ -e /usr/lib/cid/backup/lightdm.conf ]; then
	cp -f /etc/lightdm/lightdm.conf /usr/lib/cid/snapshots/lightdm.conf
	cp -f /usr/lib/cid/backup/lightdm.conf /etc/lightdm/lightdm.conf
elif [ -e /usr/lib/cid/backup/50-unity-greeter.conf ]; then
	cp -f /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf /usr/lib/cid/snapshots/50-unity-greeter.conf
	cp -f /usr/lib/cid/backup/50-unity-greeter.conf /etc/lightdm/lightdm.conf.d/50-unity-greeter.conf
elif [ -e /usr/lib/cid/backup/50-ubuntu.conf ]; then
	cp -f /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf /usr/lib/cid/snapshots/50-ubuntu.conf
	cp -f /usr/lib/cid/backup/50-ubuntu.conf /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
fi
}


#---------------------------------------------------#


Finalizar () {

zenity --question --title="*** Closed In Directory ***" --width="480" --height="200" --window-icon=/usr/share/icons/cid.png \
--text="
	***  Procedimentos realizados com êxito!  ***


	
 Para que os procedimentos realizados possam entrar em vigor, 
 é recomendado que o sistema seja reiniciado.



		Deseja reiniciar o sistema agora?"

case $? in

	0) shutdown -rq now ; reboot ; shutdown -r now ;;

	1) Menu ;;

esac
}

#---------------------------------------------------#

Menu

#---------------------------------------------------#

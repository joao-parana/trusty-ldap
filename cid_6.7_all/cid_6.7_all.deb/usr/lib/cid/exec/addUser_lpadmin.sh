#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
#---------------------------------------------------#


if [ -e /tmp/.current_user.txt ] && [ "`grep -aw 'lpadmin' /etc/group`" != "" ]; then

	user=`cat /tmp/.current_user.txt`

	if [ "$user" != "" ]; then
		if [ "`grep -aw 'lpadmin' /etc/group | grep "$USER"`" = "" ] && [ "`id -Gn | grep -w 'lpadmin'`" = "" ]; then
			adduser $user lpadmin
		fi
	fi
fi

exit 0

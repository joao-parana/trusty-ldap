#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
#---------------------------------------------------#


if [ `id -u` -ge 10000 ]; then

 # ----- Ajustando permissões do diretório home

	chmod 700 $HOME

 # ----- Executando addUser_lpadmin.sh, adicionando os usuários do domínio ao grupo de impressão do sistema, verificando privilégios administrativos e criando histórico de perfis criados

	echo $USER > /tmp/.current_user.txt && chmod 777 /tmp/.current_user.txt

	if [ -e /usr/lib/cid/exec/addUser_lpadmin.sh ]; then
		sudo /usr/lib/cid/exec/addUser_lpadmin.sh
	fi

	if [ -e /tmp/.current_user.txt ]; then

		sed -i 's/_/-/g' /tmp/.current_user.txt
		sed -i 's/\\/_/' /tmp/.current_user.txt

		if [ "`grep -ao '_' /tmp/.current_user.txt`" != "" ]; then

			DOMAIN=`echo $USER | cut -d '\' -f1`
			user=`echo $USER | cut -d '\' -f2`

			if [ -e /usr/lib/cid/control/userLogons_history.txt ] && [ "`grep -aEw "^$DOMAIN" /usr/lib/cid/control/userLogons_history.txt | grep -Ewi "$user$"`" = "" ]; then
				echo $USER >> /usr/lib/cid/control/userLogons_history.txt
			fi

			if [ "`getent group | grep -Ew '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' | grep -Ew "^$DOMAIN" | grep -w "$user"`" != "" ] || [ "`id -Gn | grep -Ew '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)'`" != "" ];then
				group_root=1
			else
				group_root=0
			fi
		else
			if [ -e /usr/lib/cid/control/userLogons_history.txt ] && [ "`grep -ax $USER /usr/lib/cid/control/userLogons_history.txt`" = "" ]; then
				echo $USER >> /usr/lib/cid/control/userLogons_history.txt
			fi

			if [ "`getent group | grep -Ew '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -Ew '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)'`" != "" ]; then
				group_root=1
			else
				group_root=0
			fi
		fi

		rm -f /tmp/.current_user.txt
	fi

 # ----- Adicionando os admins. do domínio aos grupos de sistema

	u=`grep ':1000:' /etc/passwd | cut -d ':' -f 1`

	if [ $group_root -eq 1 ]; then
		for g in `grep -aw "$u" /etc/group | cut -d ":" -f 1`
		do
			if [ "$g" != "$u" ]; then
				if [ "`grep -aw "$g" /etc/group | grep -w "$USER"`" = "" ] && [ "`id -Gn | grep -w "$g"`" = "" ]; then
					sudo adduser $USER $g
				fi
			fi
		done
	else
		for g in `grep -aw "$u" /etc/group | cut -d ":" -f 1`
		do
			if [ "`grep -aw 'admin' /etc/group | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -w 'admin'`" != "" ] || [ "`grep -aw 'sudo' /etc/group | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -w 'sudo'`" != "" ] || [ "`sudo -l | grep -w '(ALL) NOPASSWD: ALL'`" != "" ]; then
				if [ "$g" != "$u" ] && [ "$g" != "admin" ] && [ "$g" != "sudo" ] && [ "$g" != "lpadmin" ]; then
					if [ "`grep -aw "$g" /etc/group | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -w "$g"`" != "" ]; then
						sudo deluser $USER $g
					fi
				fi
			fi
		done
	
		if [ "`grep -aw 'admin' /etc/group | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -w 'admin'`" != "" ]; then
			sudo deluser $USER admin
		fi

		if [ "`grep -aw 'sudo' /etc/group | grep -w "$USER"`" != "" ] || [ "`id -Gn | grep -w 'sudo'`" != "" ]; then
			sudo deluser $USER sudo
		fi
	fi

 # ----- Criando o "Appdata"

	if [ ! -e "$HOME/.cid/" ]; then
		mkdir -p "$HOME/.cid/"
	fi

 # ----- Contabilizando Logons

	if [ ! -e $HOME/.cid/number_logons.txt ]; then
		echo "1" > $HOME/.cid/number_logons.txt
	else
		i="`cat $HOME/.cid/number_logons.txt`"
		i=`echo $(($i+1))`
		echo "$i" > $HOME/.cid/number_logons.txt
	fi

 # ----- Importando o script de logon

	if [ "`mount | grep -w /mnt/.netlogon`" != "" ] && [ -e "/mnt/.netlogon/scripts_cid/logon.sh" ]; then
		cp -f "/mnt/.netlogon/scripts_cid/logon.sh" "$HOME/.cid/"
	fi

 # ----- Executando script de logon

	if [ -e "$HOME/.cid/logon.sh" ]; then
		sh $HOME/.cid/logon.sh
	fi

fi

# ----- Desmontando NETLOGON ----- #

if [ "`mount | grep -w /mnt/.netlogon`" != "" ]; then
	sudo umount /mnt/.netlogon
fi


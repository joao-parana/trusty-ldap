#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
# ---------------------------------------------------------------------------------------------------------- #


# ------------------- COMANDOS EXECUTADOS DURANTE LOGON COM PRIVILÉGIOS ADMINISTRATIVOS (ID 0 = ROOT)  ------------------- #

# --- ADICIONE SEU SCRIPT ABAIXO:





# --- FIM --- #
exit 0

#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
#---------------------------------------------------#



# ------- UTILITÁRIO DE CONFIGURAÇÃO PARA VERSÕES UBUNTU 10.04 A UBUNTU 12.04 (gconftool-2):


# --- EX.: APLICA O PAPEL DE PAREDE

# gconftool-2 --set --type string /desktop/gnome/background/picture_filename $HOME/.cid/wallpaper.jpg

# OBS: PARA MAIS CONFIGURAÇÕES INSTALE, E EXECUTE "gconf-editor (sudo apt-get install gconf-editor -y)"



# ------- UTILITÁRIO DE CONFIGURAÇÃO PARA VERSÕES UBUNTU 12.10 OU SUPERIORES (gsettings):


# --- EX.: APLICA O PAPEL DE PAREDE

# gsettings set org.gnome.desktop.background picture-uri file://$HOME/.cid/wallpaper.jpg

# OBS: PARA MAIS CONFIGURAÇÕES INSTALE "dconf-tools (sudo apt-get install dconf-tools -y)", E EXECUTE "dconf-editor"



# ------- MAPEANDO IMPRESSORA DE REDE:

# lpadmin -p IMP-EXEMPLO-01 -v "smb://printserver/imp-exemplo-01" -m "smb://printserver/print$/hp-deskjet_2540_series.ppd" -E



# --- FIM --- #
exit 0

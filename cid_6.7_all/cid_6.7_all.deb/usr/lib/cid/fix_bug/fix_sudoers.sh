#!/bin/sh
# By Eduardo Moraes <emoraes25@gmail.com>
#---------------------------------------------------#


if [ "`grep -aEwi '(admins.|admins)' /etc/sudoers | grep -Ewi '(domínio|domain)'`" = "" ]; then

	wbinfo -g | grep -Ewi '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' > /usr/lib/cid/tmp/group.txt

	if [ "`cat /usr/lib/cid/tmp/group.txt`" = "" ]; then
		getent group | grep -Ewi '(admins. do domínio|admins. de domínio|admins. domain|domain admins.)' | cut -d ":" -f 1 > /usr/lib/cid/tmp/group.txt
	fi

	if [ "`cat /usr/lib/cid/tmp/group.txt`" != "" ]; then

		sed -i 's/\\/\\\\/ig' /usr/lib/cid/tmp/group.txt

		sed -i 's/ /\\ /ig' /usr/lib/cid/tmp/group.txt

		sed -i "s/^/%/ig" /usr/lib/cid/tmp/group.txt

		sed -i "s/$/ ALL=(ALL) NOPASSWD: ALL/ig" /usr/lib/cid/tmp/group.txt

		cat /usr/lib/cid/tmp/group.txt >> /etc/sudoers

		if [ "`grep -aw 'fix_sudoers.sh' /etc/sudoers`" != "" ]; then
			sed -i '/fix_sudoers.sh/d' /etc/sudoers
		fi

		if [ "`grep -aw 'fix_sudoers.sh' /usr/lib/cid/exec/uid_logon.sh`" != "" ]; then
			sed -i '/fix_sudoers.sh/d' /usr/lib/cid/exec/uid_logon.sh
		fi
	fi
else
	if [ "`grep -aw 'fix_sudoers.sh' /etc/sudoers`" != "" ]; then
		sed -i '/fix_sudoers.sh/d' /etc/sudoers
	fi

	if [ "`grep -aw 'fix_sudoers.sh' /usr/lib/cid/exec/uid_logon.sh`" != "" ]; then
		sed -i '/fix_sudoers.sh/d' /usr/lib/cid/exec/uid_logon.sh
	fi
fi

exit 0
